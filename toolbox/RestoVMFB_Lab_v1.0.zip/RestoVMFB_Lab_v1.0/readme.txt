RestoVMFB

*******************************************************
* author: Audrey Repetti         		              *
* institution: LIGM -  Universite de Marne la Vallee  *
* date: Wednesday, April 17th 2013   	              *
* License CeCILL-B                                    *
*******************************************************


*****************************************************
* RECOMMENDATIONS:                                  *
* This toolbox is designed to work with             *
* Matlab 7.0                                        *
*****************************************************


---------------------------------------------------------------------------
DESCRIPTION:
This toolbox allows to restore an image degraded by a linear operator 
and Gaussian Dependant noise with variance depending linearly on the image.
The considered criterion is composed with  
-> The neg-log-likelihood of the noise distribution as data fidelity term
F(x) = 1/2 (sum((H(x)-y)^2 / (a * H(x) + b ) + log(a * H(x) + b)))
-> The indicator function allowing to constraint the dynamic range 
of the restored image into [xmin,xmax]
R1(x) = i_[xmin,xmax](x)
-> The isotropic total variation favorizing piecewise constant images
R2(x) = TV(x)

The restoration process uses either :
- the Majorize-Minimize Variable Metric Forward-Backward Algorithm
- the Forward-Backward Algorithm
- the Fast Iterative Soft Tresholding Algorithm (FISTA)

The inner loop for computing the proximity operator of R = R1 + R2 is
performed using the Dual Forward-Backward Algorithm.

This toolbox consists of 3 subfolders:
1)  Images : contains some standard test images
2)  Algorithm : contains the optimization algorithms
3)  Tools : contains additional tools for proximal calculus

--------------------------------------------------------------------------- 
SPECIFICATIONS for using RestoVMFB:

The demo file demodeblurring.m running a deconvolution example is provided. 
 
---------------------------------------------------------------------------
RELATED PUBLICATION:

#  E. Chouzenoux, J.-C. Pesquet and A. Repetti. "Variable Metric Forward-Backward 
Algorithm for Minimizing the Sum of a Differentiable Function and a Convex Function"
Submitted, 2013. Available at http://www.optimization-online.org/DB_FILE/2013/01/3749.pdf




