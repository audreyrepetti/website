function p = proxind(x,xmin,xmax)

p = min(max(x,xmin),xmax);