function sigma_max = max_singular_value(HtH,x,niter)
%Compute maximal singular value of matrix A, given by multiplication
%operators multA(x,par),multAt(x,par); 
%input x should be a random vector


normx = norm(x);

for i=1:niter,
    x=HtH(x);
    sigma_max = sqrt(norm(x))/sqrt(normx);
    normx = norm(x);
end